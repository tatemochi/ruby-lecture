# 課題3-2

# 課題2-4で作成したメソッド「quad_eq」のテストを作成してください。
#
# 以下に、課題2-4で作成した「quad_eq」メソッドをコピーします。
def quad_eq(a,b,c)
  l=-b
  b**=2
  if b - 4*a*c < 0 #虚数解か実数解か求める
      false
  else
      m=Math.sqrt(b - 4*a*c)
      return (l+m)/(2*a)
  end
end

# 以下に、テストプログラムを書いてください。

require 'minitest/autorun'

class SampleTest < Minitest::Test
    def test_sample
        assert_equal  5.0,quad_eq(1,-6,5)
        assert_equal  -1.0,quad_eq(1,2,1)
        assert_equal  false,quad_eq(2,4,50) 
    end
end
