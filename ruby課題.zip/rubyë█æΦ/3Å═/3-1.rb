# 課題3-1

# 課題2-3で作成したメソッド「leap_year?」のテストを作成してください。
#
# 以下に、課題2-3で作成した「leap_year?」メソッドをコピーします。
def leap_year?(year)
 if year%4==0
     if year%100==0
         if year%400==0
             true
         else
             false
         end
     else
         true
     end
 else
     false
 end
end

# 以下に、テストプログラムを書いてください。
require 'minitest/autorun'

class SampleTest < Minitest::Test
    def test_sample
        assert_equal  true,leap_year?(2020) #4,100,400で割り切れる うるう年
        assert_equal  true,leap_year?(2000) #4で割り切れる 100で割り切れない うるう年
        assert_equal  false,leap_year?(2003) #4で割り切れない うるう年ではない
        assert_equal  false,leap_year?(2100) #4,100で割り切れる400で割り切れない うるう年ではない
    end
end