# 課題E-1

# 料理のレシピを表現するRecipeクラスを、以下に従って定義してください。
# ・Recipeクラスのオブジェクト作成時に、 料理名を登録する。
# ・１⼈前の材料名のリストと分量を、{ 材料名 => 数量 } の形式の
#   ハッシュで設定でき、登録時に内容を表示する。
# ・ｎ⼈前の材料名のリストと分量が表⽰できる。
# ・料理の⼿順を設定・表⽰できる(手順は文字列でよい)。
# ・レシピを作成した⼈の名前を設定・表⽰できる。

# 以下に、プログラムを書いてください。
class Recipe
    def initialize(name)
        @name = name
    end
    
    def zairyou
        @ingred = {}
        loop do
            puts '材料名を入力してください。 (終了時 endと入力)'
            ingredn = gets.chomp
            break if 'end' == ingredn
            ingred = ingredn.to_sym
            puts '数量を入力してください(一人前)'
            num = gets.to_f
            @ingred[ingred] = num
        end
        puts '一人前'
        @ingred.each do |key,value|
            puts "・材料名:#{key}  ・数量:#{value}"
        end
    end
    
    def numerous
        puts '何人前つくりますか？'
        n = gets.to_i
        @ingred.each do |key,value|
            puts "・材料名:#{key}  ・数量:#{value*n}"
        end
    end
    
    def step
        @step = []
        c = 1
        stepc = 0
        loop do
             puts "手順#{c}を入力してください。 (終了時 endと入力)"
             steps = gets.chomp
             break if 'end' == steps
             @step[stepc] = steps.to_s
             c += 1
             stepc += 1
        end
        c1 = 1
        @step.each do |n|
            puts "手順#{c1}:#{n}"
            c1 += 1
        end
    end
    
    def chef
        puts 'レシピ作成者の名前は？'
        chef = gets.to_s
        puts "作成者#{chef}"
    end
end

loop do
    puts '料理名を入力してください'
    name = gets.to_s
    recipe = Recipe.new(name)
    recipe.zairyou
    recipe.numerous
    recipe.step
    recipe.chef
    puts '終了しますか？　-> yesで終了'
    break if 'yes' == gets.chomp
end