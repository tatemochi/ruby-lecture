# 課題7-2

# 課題4-3の数当てゲームを、以下に従ってクラスに定義してください。
# ・数当てゲームを表す「NumberGame」クラスを作成する。
# ・正解の数値の範囲は1〜1000ではなく1〜nとして、
#   NumberGameクラスのオブジェクト作成時に、引数で渡した整数をnの初期値とする。
# ・ゲームを開始するstartメソッドを定義する。
# ・プログラムの読みやすさや拡張性も考えて、必要な機能をメソッドとして定義する。

# 以下に、プログラムを書いてください。
class  NumberGame
    def initialize(n)
        @n = n 
        @seikai = rand(1..@n) #1-n中の乱数を一つ生成
    end
    attr_accessor :n
    
    
    def start
        puts 'ゲームを開始します。'
        c = 0
        loop do
            puts "1-#{@n}の数値を一つ入力してください"
            key = gets.to_f
            c +=1
            break if key == @seikai
            if key < @seikai
              puts '正解は入力された数値よりも大きいです。'
            else
              puts '正解は入力された数値よりも小さいです。'
            end
        end
        puts "#{c}回の回答で正解しました。"
        
    end
    
    def confirm
        puts 'もう一度プレイする　->　r'
        re = gets.chomp
        if re == 'r'
            puts '好きな数字を入力してください。'
            @n = gets.to_i
            @seikai = rand(1..@n)
        else 
            false
        end
    end
end

puts '好きな数字を入力してください。'
nu = gets
nu = nu.to_i
num = NumberGame.new(nu)
loop do
     num.start　#ゲームスタート
     break if num.confirm == false　#false(rが入力)が返ってきたら終了
end