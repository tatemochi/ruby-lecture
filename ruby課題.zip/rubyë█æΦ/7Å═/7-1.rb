# 課題7-1

# 「ロボット」を表すRobotクラスを、以下に従って定義してください。
# ・Robotクラスのオブジェクト作成時に、 ロボットの名前を登録する。
# ・Robotオブジェクトに、タイプ(型)が設定できる。
# ・Robotオブジェクトに、以下の挨拶を返すgreetingメソッドを定義する。
#   「こんにちは。私は[タイプ]型ロボットの[名前]です。」
#
#
# 以下は、データです。(書き換えない)
robot_data = []
robot_data << { name: 'ドラえもん', type: '猫' }
robot_data << { name: 'アトム', type: '人' }
robot_data << { name: 'ルンバ', type: '掃除機' }
robot_data << { name: 'Pepper', type: '人' }

# 以下は、クラス定義です。
class Robot
  def initialize(robotname)
      @name = robotname
  end
  attr_accessor :type
  def greeting
      "「こんにちは。私は[#{@type}]型ロボットの[#{@name}]です。」"
  end
end

# 以下は、プログラムの実行です。(書き換えない)
robot_data.each do |data|
  robot = Robot.new(data[:name])
  robot.type = data[:type]
  puts robot.greeting
end
