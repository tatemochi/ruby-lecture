# 課題B-1

# 二次元ベクトル(x, y)を扱う「Vector」クラスを定義してください。
#
# このクラスでは、少なくとも以下の３つのメソッドが使える必要があります。
# ・newメソッド
#  ２つの値x, yを指定してベクトルの値を設定する。
# ・to_sメソッドhttps://paiza.cloud/#
#   オブジェクトが保持している２つの値x, yを元にして、"(x, y)”のような文字列を返す。
# ・lengthメソッド
#   ベクトルの大きさを返す。
#   (平方根を求めるにMath::sqrtメソッドを利用してもよい。)
#
# さらに、各自で考えたメソッドを1つ以上追加してください。

# 以下に、プログラムを書いてください。

class Vector
    def initialize(x,y)
        @x = x
        @y = y
    end
    
    def to_s
        "座標は(#{@x},#{@y})です。"
    end
    
    def length
        l = Math.sqrt(@x * @x + @y * @y)
    end
    
    def confirm
        puts '終了しますか？-> yesを入力'
        ans = gets.chomp
        if ans == 'yes'
            false
        else
            true
        end
    end
end

loop do
     puts 'xの値を入力してください'
     x = gets.to_i
     puts 'yの値を入力してください'
     y = gets.to_i
     
     vector = Vector.new(x,y)
     puts vector.to_s
     puts "ベクトルの大きさは#{vector.length}です。"
     
     break if vector.confirm == false #false(yesが入力)が返ってきたら終了
end
    