# 課題5-3

# 課題5-2で作成した「string_count」メソッドのテストを作成してください。
#
# テストケースは最低でも、['japan', 'us', 'india', 'china'] を渡された場合と、
# 空の配列を渡された場合の、2パターンを作成してください。
#
# 以下の文で、課題5-2のファイルを取り込みます。
require_relative './5-2.rb'

# 以下に、テストプログラムを書いてください。
require 'minitest/autorun'

class String_Count < Minitest::Test
    def test_string_count
        assert_equal({ :japan => 5, :us => 2, :india => 5, :china => 5 },string_count(['japan', 'us', 'india', 'china']))
        assert_equal({},string_count([]))
    end
end
