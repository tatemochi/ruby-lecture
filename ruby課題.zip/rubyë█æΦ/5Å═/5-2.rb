# 課題5-2

# 文字列を要素にもつ配列を引数で渡すと、要素をキーに、その要素の文字数を値とする
# ハッシュを戻り値として返す「string_count」メソッドを作成してください。
# なお、空の配列を渡した場合、空のハッシュを返すものとします。
#
# 【例１】
# string_count(['japan', 'us', 'india', 'china'])
# =>
# { :japan => 5, :us => 2, :india => 5, :china => 5 }
#
# 【例２】
# string_count([])
# =>
# {}
#
# 以下は、メソッド定義です。
def string_count(array)
    num = 0
    hash0 = {}
   array.each do |n|
       hash0[n.sym] = n.size
    end
    return hash0
end

# 以下に、動作確認用のプログラムを書いてもよいです。
string_count(['japan', 'us', 'india', 'china']).each do |key,value|
    puts "#{key}:#{value}"
end