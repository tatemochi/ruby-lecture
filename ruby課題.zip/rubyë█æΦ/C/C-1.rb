# 課題C-1

# 身長(cm)と体重(kg)を入力させて、以下の情報を表示させる「BMI」クラス定義してください。
#   BMI値、BMIの判定、肥満度(%)、肥満度の判定
#
# 【計算方法】
# BMI = 体重(kg) / (身長(m) * 身長(m))
# BMIの判定
#   18.5未満：低体重
#   18.5～25未満：標準の体重
#   25以上：肥満
# 肥満度(%) = ((体重(kg) - 標準体重(kg)) * 100) / 標準体重(kg)
# （標準体重(kg) = 身長(m) * 身長(m) * 22）
# 肥満度の判定
# -10%未満：やせ
# -10%～+10%未満：正常
# +10%～+20%未満：肥満気味
# +20%以上：肥満
#

# 以下に、プログラムを書いてください。

class BMI
    def initialize(h,w)
        @h = h/100
        @w = w
    end
    
    def bmical #BMI値を計算しBMIを表示
        @bmi =  @w / (@h * @h) 
        return puts "BMI値は#{@bmi}です。"
    end
    
    def bmijd　#BMIを判定し表示
        if @bmi < 18.5
            puts '低体重'
        elsif @bmi >=25
            puts '肥満'
        else
            puts '標準の体重'
        end
    end
    
    def fatcal　#肥満度を計算し表示
        @sw = @h * @h * 22
        @fat = ((@w - @sw) * 100) / @sw
        return puts "肥満度は#{@fat}%です。"
    end
    
    def fatjd #肥満度を判定し表示
        if @fat < -10
            puts 'やせ'
        elsif @fat > -10 && @fat < 10
            puts '正常'
        elsif 10 < @fat  && @fat < 20
            puts '肥満気味'
        else
            puts '肥満'
        end
    end
        
    def confirm
        puts '終了しますか？-> yesを入力'
        ans = gets.chomp
        if ans == 'yes'
            false
        else
            true
        end
    end
end

loop do
     puts '身長(cm)を入力してください'
     w = gets.to_f
     puts '体重(kg)を入力してください'
     h = gets.to_f
     
     helth = BMI.new(w,h)
     helth.bmical
     helth.bmijd
     helth.fatcal
     helth.fatjd

     break if helth.confirm == false　#false(yesが入力)が返ってきたら終了
end
