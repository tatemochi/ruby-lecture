# 課題D-1

# 次に示す、「Polygon」クラスに以下の機能を持つメソッドを追加してください。
# ・図形をX方向にX倍にY方向にY倍、拡大または、縮小した図形の座標を返すメソッド
# ・図形をN度、反時計回りに回転した図形の座標を返すメソッド
# ・図形をX, Y(距離)、平行移動した図形の座標を返すメソッド
#
# 【ヒント】
# Rubyには、行列を扱うMatrixクラスがあります。Matrixクラスを使うには下記の様に記述します。
# require 'Matrix'
# リファレンスマニュアル: http://docs.ruby-lang.org/ja/2.1.0/library/matrix.html

# 以下は、データです。(書き換えない)
triangle = [{ x: 10, y: 0 }, { x: 50, y: 100 }, { x: 150, y: 0 }]
square   = [{ x: 0, y: 0 }, { x: 0, y: 100 }, { x: 100, y: 100 },
            { x: 100, y: 0 }]
pentagon = [{ x: 0, y: 100 }, { x: 100, y: 150 }, { x: 200, y: 100 },
            { x: 150, y: 0 }, { x: 50, y: 0 }]

# 以下は、クラス定義です。
class Polygon
  def initialize(figure)
      @figure0 = []
      figure.each do |n|
         @figure0.push(n)
      end
  end
  
  def su(x,y) #拡大or縮小
      exfigure = []
      @figure0.each do |hash|
          exfigure << {x: hash[:x]*x, y: hash[:y]*y} #x値をx倍とy値をy倍した座標をexfigureに入れる
      end
      exfigure
  end
  
  def kaiten(degree)
      kaifigure = []
      cos0 = (Math.cos(degree * Math::PI / 180  ))
      sin0 = (Math.sin(degree * Math::PI / 180 ))
      @figure0.each do |hash|
          x = hash[:x]
          y = hash[:y]
          kaifigure << {x: x*cos0 - y*sin0 , y: x*sin0 + y*cos0} #x値、y値をそれぞれdegree度回転させたときの座標をkaifigureに入れる
      end
      kaifigure
  end
  
  def idou(x,y)
      idfigure = []
      @figure0.each do |hash|
          idfigure << {x: hash[:x] + x, y: hash[:y] + y} #x値、y値をそれぞれx、yだけ移動させたときの座標をidfigureに入れる
      end
      idfigure
  end
      
      
  
  def pr
      @figure0.each do |n|
          puts "#{n}" 
      end
  end
end

# 以下は、オブジェクトの生成です。
p1 = Polygon.new(triangle)
p2 = Polygon.new(square)
p3 = Polygon.new(pentagon)

# 以下に、動作確認用のプログラムを書いてもよいです。
#p1確認
p1.pr
p1.su(2,2).each do |n|
    puts "#{n}"
end

p1.kaiten(45).each do |n|
    puts "#{n}"
end

p1.idou(2,2).each do |n|
    puts "#{n}"
end

#p2確認
p2.pr
p2.su(2,2).each do |n|
    puts "#{n}"
end

p2.kaiten(45).each do |n|
    puts "#{n}"
end

p2.idou(2,2).each do |n|
    puts "#{n}"
end

#p3確認
p3.pr
p3.su(2,2).each do |n|
    puts "#{n}"
end

p3.kaiten(45).each do |n|
    puts "#{n}"
end

p3.idou(2,2).each do |n|
    puts "#{n}"
end