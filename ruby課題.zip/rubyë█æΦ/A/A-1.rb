# 課題A-1

# 「ズン」「ドコ」のいずれかをランダムで出力し続けて
# 「ズン」「ズン」「ズン」「ズン」「ドコ」の配列が出たら
# 「キ・ヨ・シ！」と出力するメソッドを定義してください。
#
# Javaでズンドコキヨシ
# https://qiita.com/y-sugasawa/items/35828ee9a0ac531689b6

# 以下に、プログラムを書いてください。
def kiyosi
c = 0
zundoko = ['ズン','ドコ']
pack = []
loop do
    pack[c] = zundoko[rand(0..1)]
    if pack[c] == 'ドコ'     　　　　　            #現在位置でドコが発生
        if pack[c-1] == 'ズン'　　　　             #一つ前がズンである
            if pack[c-2] == 'ズン'                 #二つ前もズンである
                if pack[c-3] == 'ズン'             #三つ前もズンである
                    if pack[c-4] == 'ズン'         #四つ前もズンである
                        puts pack[c]               #=>「ズン　ズン　ズン　ズン　ドコ」が発生
                        break
                    end
                end
            end
        end
    end
    puts pack[c]
    c +=1
end

puts 'キ・ヨ・シ！'

end

kiyosi 
