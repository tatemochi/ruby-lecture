# 課題2-3

# 画面から西暦を入力して、うるう年であれば「うるう年です。」、そうでなければ「うるう年ではありません。」と
# 画面に表示させるプログラムを作成してください。
#
# 最初に、引数で与えられた西暦(数字)がうるう年かどうが判定するメソッド「leap_year?」を定義します。
# このメソッドは、うるう年であればtrueを、そうでなければfalseを戻り値として返します。
#
# 以下は、メソッド定義です。

def leap_year?(year)
 if year%4==0
     if year%100==0
         if year%400==0
             true
         else
             false
         end
     else
         true
     end
 else
     false
 end
end

# 以下に、leap_year?を使ったプログラムを書いてください。

puts "西暦を入力してください"
year=gets
year=year.to_f

if leap_year?(year)==true
    puts "うるう年です。"
else
    puts "うるう年ではありません。"
end