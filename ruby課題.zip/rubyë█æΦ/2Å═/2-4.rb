# 課題2-4

# 画面からa、b、cを入力して、二次方程式「a * x^2 + b * x + c = 0」の実数解を
# 画面に表示させるプログラムを作成してください。
#
# 最初に、引数a、b、cで与えられた数字から、二次方程式の実数解のうち一つを
# 戻り値として返すメソッド「quad_eq」を定義します。
#
# 以下は、メソッド定義です。
def quad_eq(a, b, c)
  l=-b
  b**=2
  if b - 4*a*c < 0 #虚数解か実数解か判定
      false
  else　
      m=Math.sqrt(b - 4*a*c)　#解を返す
      return (l+m)/(2*a)
  end
end

# 以下に、quad_eqを使ったプログラムを書いてください。

puts 'aの値を入力してください'
a=gets
puts 'bの値を入力してください'
b=gets
puts 'cの値を入力してください'
c=gets

a=a.to_f
b=b.to_f
c=c.to_f

answer=quad_eq(a,b,c)
if answer == false
    puts '虚数解です。'
    
else
    puts "実数解の一つは#{answer}です。"
end

